# macOS Security Audit Tool

Терминальная утилита для полного аудита безопасности macOS. Один скрипт — один запуск — HTML-отчёт с оценкой и готовыми командами исправления.

![macOS](https://img.shields.io/badge/macOS-12%2B-000000?logo=apple&logoColor=white)
![Arch](https://img.shields.io/badge/Intel%20%26%20Apple%20Silicon-universal-8A2BE2)
![License](https://img.shields.io/badge/license-MIT-green)
![Shell](https://img.shields.io/badge/bash-portable-blue)

---

## Что это

Bash-скрипт, который за 30 секунд проверяет ~55 параметров безопасности macOS и генерирует детальный HTML-отчёт на рабочий стол.

- **Security Score 0–100** — взвешенная оценка безопасности
- **PASS / FAIL / WARN** — статус каждой проверки
- **Quick Fix** — все команды исправления в одном блоке, копируются в один клик
- **Manual Recommendations** — то, что скрипт не может исправить автоматически

## Что проверяется

### 1. System Integrity
SIP, FileVault, Gatekeeper, XProtect, Rapid Security Responses, автоматические обновления, EFI integrity (Intel) / Secure Boot (Apple Silicon)

### 2. Network Security
Application Firewall + Stealth Mode, Mullvad VPN (туннель, DNS leak, routing), LuLu (outbound firewall), sharing services (SSH, File Sharing, Screen Sharing, Remote Management, и др.), AirDrop, Bluetooth, Wi-Fi known networks

### 3. Privacy Controls
Apple Analytics, Crash Reporter, персонализированная реклама, Siri + Siri Data Sharing, Spotlight Suggestions, Safari Suggestions, Location Services, DuckDuckGo Browser, обнаружение браузеров с повышенной телеметрией

### 4. Access & Authentication
Пароль при screensaver/sleep, задержка запроса, auto-login, password hints, login window, display sleep timeout, SSH, sudo timeout, Find My Mac

### 5. Application Security
Launch Agents / Launch Daemons (3 уровня аудита с whitelist), Login Items, Gatekeeper Allow Anywhere, quarantine, Objective-See tools (BlockBlock, KnockKnock, OverSight)

### 6. Performance & Health
Memory pressure, swap, disk space, user caches, APFS snapshots, battery health, optimized charging, uptime

### Бонус: TCC Permissions Audit
Камера, микрофон, запись экрана, полный доступ к диску, Accessibility, Input Monitoring — какие приложения имеют доступ (требует sudo)

## Требования

- **macOS 12+** (Monterey, Ventura, Sonoma, Sequoia)
- **Intel или Apple Silicon** — скрипт автоматически определяет архитектуру
- **Нет зависимостей** — только стандартные утилиты macOS
- **sudo** — опционально, для расширенных проверок (Firewall, TCC, SSH). Без sudo часть проверок будет пропущена

## Установка и запуск

```bash
# Скачать
curl -sL https://raw.githubusercontent.com/YOUR_USERNAME/macos-security-audit/main/macos_security_audit.sh -o macos_security_audit.sh

# Сделать исполняемым
chmod +x macos_security_audit.sh

# Запустить
./macos_security_audit.sh
```

Или клонировать репозиторий:

```bash
git clone https://github.com/YOUR_USERNAME/macos-security-audit.git
cd macos-security-audit
chmod +x macos_security_audit.sh
./macos_security_audit.sh
```

Скрипт запросит пароль (sudo) один раз. HTML-отчёт появится на Desktop и автоматически откроется в браузере.

## HTML-отчёт

- Тёмная тема, высокий контраст, минималистичный дизайн
- Один self-contained файл — открывается в любом браузере оффлайн
- Security Score с визуальным кольцом
- Click-to-copy для всех команд исправления
- Секция Quick Fix — все FAIL-команды в одном блоке

## Особенности

### Mullvad VPN-aware
Скрипт знает про Mullvad VPN и:
- Проверяет наличие VPN-туннеля (utun)
- Сравнивает DNS-серверы с Mullvad DNS (10.64.0.1, 100.64.0.*)
- Проверяет маршрутизацию через VPN
- Не помечает Mullvad-процессы как подозрительные

### LuLu-aware
- Проверяет наличие и работу LuLu (outbound firewall от Objective-See)
- LuLu в whitelist при аудите Launch Agents/Daemons

### DuckDuckGo-aware
- Проверяет наличие DuckDuckGo Browser
- Обнаруживает браузеры с повышенной телеметрией (Chrome, Edge, Opera)

### Портативность
- Работает на Intel и Apple Silicon
- Автоматическое определение архитектуры (`uname -m`)
- Нет хардкод-путей, нет внешних зависимостей
- Один файл — скопировал на любой Mac, запустил

## Безопасность

- Скрипт **только читает** настройки — ничего не меняет без вашего ведома
- Все fix-команды выводятся как рекомендации — запускать их решаете вы
- Деструктивные действия помечены предупреждениями
- Sudo-сессия автоматически завершается по окончании аудита

## Структура репозитория

```
.
├── macos_security_audit.sh    # Основной скрипт
├── README.md                  # Документация
├── LICENSE                    # MIT License
└── .gitignore
```

## Roadmap

- [ ] Автозапуск по расписанию через launchd
- [ ] Сравнение отчётов между запусками (diff)
- [ ] Экспорт в JSON для автоматизации
- [ ] Профили hardening (basic / strict / paranoid)
- [ ] Homebrew formula

## Лицензия

[MIT](LICENSE) — используйте свободно.

---

> Скрипт ориентирован на CIS Benchmark для macOS и принцип defense-in-depth. Каждый слой компенсирует потенциальную слабость другого.
